/*
Windows 96 Internals Inspector.

(C) Windows 96 Team 2021.
*/

function objKeyWalk(_o, ignores = ["jQuery"]) {
    let objCache = [];

    function keyWalk(o) {
        if(objCache.includes(o)) return [];
        else objCache.push(o);

        let keys = Object.keys(o);

        // Remove ignored items

        keys.forEach((v, index)=>{
            for(let i of ignores) {
                if(v.includes(i)) {
                    keys[index] = null;
                }
            }
        });
        

        for(let k of keys)
            if(k == null)
                continue;
            else
                if((typeof o[k] == 'object') && (o[k] != null)) 
                    for(let wk of keyWalk(o[k]))
                        keys.push(k + "." + wk);

        return keys;
    }

    return keyWalk(_o);
}

class WInspectorApplication extends w96.WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        
        this.mainwnd = this.createWindow({
            title: "Win96 Internals Inspector",
            icon: w96.ui.Theme.getIconUrl("small/exec"),
            body: `
                <div class="appbar"></div>
                <div class="tab-control"></div>
            `,
            bodyClass: "winspector-app",
            initialHeight: 290,
            initialWidth: 370
        }, true);

        const appBar = new w96.ui.MenuBar();
        
        appBar.addRoot("File", [
            {
                type: "normal",
                label: "Exit",
                onclick: ()=>this.terminate()
            }
        ]);

        appBar.addRoot("Help", [
            {
                type: "normal",
                label: "About",
                onclick: ()=>w96.ui.DialogCreator.create({
                    title: "About",
                    icon: "info",
                    body: "Win96 Internals Inspector v1.0<br><br>(C) windows96.net 2021"
                })
            }
        ]);

        const body = this.mainwnd.getBodyContainer();

        // Add app menu
        body.querySelector('.appbar').replaceWith(appBar.getMenuDiv());

        // Setup tab controls
        const tabCtrl = new w96.ui.components.TabControl();

        // Mounted Disks tab
        let mainPage = tabCtrl.addPage("Mounted Disks", (container)=>{
            const fsView = new w96.ui.components.ListBox();

            const mounted = w96.FS.list();

            for(let mount of mounted) {
                let mntObj = w96.FS.get(mount);
                let itemEl = fsView.addItem(`${mntObj.prefix} [label=${mntObj.volumeLabel},driver=${mntObj.driverName},features=[${mntObj.features}]]`, mount);
                itemEl.addEventListener('dblclick', ()=>{
                    // Open the mounted drive
                    w96.sys.execCmd("explorer", [mntObj.prefix + "/"]);
                });
            }

            const fsvEl = fsView.getElement();
            fsvEl.classList.add('mnt-box');

            container.appendChild(fsvEl);
        });

        tabCtrl.addPage("API Walk", (container)=>{
            const apiView = new w96.ui.components.ListBox();

            for(let k of objKeyWalk(w96)) {
                apiView.addItem(k, k);
            }

            const apiEl = apiView.getElement();
            apiEl.classList.add('api-box');

            container.appendChild(apiEl);
        });

        body.querySelector('.tab-control').replaceWith(tabCtrl.getElement());
        
        // Create footer
        const footer = document.createElement('footer');
        footer.classList.add('w96-footer');
        footer.innerText = `Windows 96 v${w96.sys.rel.getVersionString()}`;
        body.appendChild(footer);

        // Append CSS
        
        body.appendChild(await w96.sys.loader.createStyleFromPath("C:/local/winspector/main.css"));

        // Open default tab
        tabCtrl.openPage(mainPage);

        this.mainwnd.show();
    }
}

registerApp("winsp", [], function(args) {
    return w96.WApplication.execAsync(new WInspectorApplication());
});