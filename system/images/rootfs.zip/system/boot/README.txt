Files placed here will load on boot.

auto-sys.js is the default boot file and always executes first, no matter what.

Supported file types are: CSS, JavaScript, WASM

If you wish to load files in order, you may prefix them using a number since the directory is read in alphabetical order.

Subdirectories are not read (other than apps for applications), so you can create a subdirectory to hold any data if you wish.

Take care of any malicious script, some may make your system unbootable :)